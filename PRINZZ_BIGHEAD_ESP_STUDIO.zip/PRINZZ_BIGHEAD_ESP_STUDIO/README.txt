PRINZZ BIG HEAD + NAME/DISTANCE ESP
===================================

This package is for Roblox Studio experiences you own or are authorized to
develop. It is not a Delta executor script and does not bypass Roblox security.

INSTALL
-------
1. Open your own experience in Roblox Studio.
2. Add ServerScriptService/PrinzzBigHead.server.lua as a Script under
   ServerScriptService.
3. Add StarterPlayer/StarterPlayerScripts/PrinzzBigHead.client.lua as a
   LocalScript under StarterPlayer > StarterPlayerScripts.
4. In the server script, replace 123456789 with your Roblox UserId.
5. Test with Studio's Start Server and multiple players.

FEATURES
--------
- Server-applied R15 HeadScale effect for players who are not friends of
  configured admin accounts.
- Friend exclusion checked on the server.
- Local Name + Distance ESP labels.
- Crimson red mobile-friendly panel with ON/OFF and hide/show controls.

NOTES
-----
- The Big Head feature uses HumanoidDescription.HeadScale; avatar/game
  configuration may affect availability.
- Friend exclusion is based on friendship with configured admin account(s).
- The ESP is a local visual aid in your own experience.
- This package does not include anti-cheat evasion or executor functionality.
