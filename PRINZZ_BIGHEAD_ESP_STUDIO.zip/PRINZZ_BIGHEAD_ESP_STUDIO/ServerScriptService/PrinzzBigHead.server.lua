-- PRINZZ BIG HEAD + ESP | SERVER SCRIPT
-- Install in ServerScriptService in an experience you own.
-- Replace 123456789 with your Roblox UserId.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local ADMIN_USER_IDS = {
    [123456789] = true, -- CHANGE THIS
}

local BIG_HEAD_SCALE = 2
local remote = ReplicatedStorage:FindFirstChild("PrinzzBigHeadRemote")
if not remote then
    remote = Instance.new("RemoteEvent")
    remote.Name = "PrinzzBigHeadRemote"
    remote.Parent = ReplicatedStorage
end

local bigHeadOn = false
local originalScales = {}

local function isAdmin(player)
    return ADMIN_USER_IDS[player.UserId] == true
end

local function isFriendOfAnAdmin(target)
    for _, admin in ipairs(Players:GetPlayers()) do
        if ADMIN_USER_IDS[admin.UserId] and target ~= admin then
            local ok, result = pcall(function()
                return target:IsFriendsWith(admin.UserId)
            end)
            if ok and result then
                return true
            end
        end
    end
    return false
end

local function setHeadScale(target, enabled)
    if isFriendOfAnAdmin(target) then
        return
    end

    local character = target.Character
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    if not humanoid then
        return
    end

    local ok, description = pcall(function()
        return humanoid:GetAppliedDescription()
    end)
    if not ok or not description then
        warn("[PRINZZ] Cannot read avatar description for " .. target.Name)
        return
    end

    if originalScales[target.UserId] == nil then
        originalScales[target.UserId] = description.HeadScale
    end

    description.HeadScale = enabled and BIG_HEAD_SCALE or originalScales[target.UserId]
    local applied, err = pcall(function()
        humanoid:ApplyDescription(description)
    end)
    if not applied then
        warn("[PRINZZ] ApplyDescription failed: " .. tostring(err))
    end
    description:Destroy()
end

local function applyBigHeadToPlayers()
    for _, target in ipairs(Players:GetPlayers()) do
        if target ~= nil and not isFriendOfAnAdmin(target) then
            setHeadScale(target, bigHeadOn)
        end
    end
end

remote.OnServerEvent:Connect(function(player, action, value)
    if not isAdmin(player) then
        warn("[PRINZZ SECURITY] Unauthorized request from " .. player.Name)
        return
    end

    if action == "SetBigHead" and typeof(value) == "boolean" then
        bigHeadOn = value
        applyBigHeadToPlayers()
    end
end)

local function onPlayerAdded(player)
    player.CharacterAdded:Connect(function()
        task.wait(1.5)
        if bigHeadOn and not isFriendOfAnAdmin(player) then
            setHeadScale(player, true)
        end
    end)
end

Players.PlayerAdded:Connect(onPlayerAdded)
for _, player in ipairs(Players:GetPlayers()) do
    onPlayerAdded(player)
end

Players.PlayerRemoving:Connect(function(player)
    originalScales[player.UserId] = nil
end)

print("[PRINZZ] Big Head server system ready.")
