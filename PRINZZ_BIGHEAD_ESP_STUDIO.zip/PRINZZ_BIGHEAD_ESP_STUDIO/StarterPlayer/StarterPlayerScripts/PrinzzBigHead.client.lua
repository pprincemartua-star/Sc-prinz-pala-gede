-- PRINZZ BIG HEAD + NAME/DISTANCE ESP | CLIENT
-- Install as a LocalScript in StarterPlayer > StarterPlayerScripts.
-- Intended for your own Roblox experience.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local localPlayer = Players.LocalPlayer
local remote = ReplicatedStorage:WaitForChild("PrinzzBigHeadRemote")

local bigHeadEnabled = false
local espEnabled = false
local espObjects = {}

local gui = Instance.new("ScreenGui")
gui.Name = "PRINZZ_BIGHEAD_ESP"
gui.ResetOnSpawn = false
gui.Parent = localPlayer:WaitForChild("PlayerGui")

local panel = Instance.new("Frame")
panel.Size = UDim2.fromOffset(285, 270)
panel.Position = UDim2.new(0.5, -142, 0.5, -135)
panel.BackgroundColor3 = Color3.fromRGB(27, 15, 21)
panel.BorderSizePixel = 0
panel.Parent = gui
Instance.new("UICorner", panel).CornerRadius = UDim.new(0, 13)

local outline = Instance.new("UIStroke")
outline.Color = Color3.fromRGB(190, 35, 62)
outline.Thickness = 1.5
outline.Parent = panel

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -20, 0, 42)
title.Position = UDim2.fromOffset(10, 5)
title.BackgroundTransparency = 1
title.Text = "PRINZZ  |  BIG HEAD + ESP"
title.TextColor3 = Color3.fromRGB(255, 75, 100)
title.Font = Enum.Font.GothamBold
title.TextSize = 15
title.Parent = panel

local function makeButton(text, y)
    local button = Instance.new("TextButton")
    button.Size = UDim2.new(1, -24, 0, 39)
    button.Position = UDim2.fromOffset(12, y)
    button.BackgroundColor3 = Color3.fromRGB(135, 25, 48)
    button.TextColor3 = Color3.new(1, 1, 1)
    button.Font = Enum.Font.GothamSemibold
    button.TextSize = 13
    button.Text = text
    button.Parent = panel
    Instance.new("UICorner", button).CornerRadius = UDim.new(0, 8)
    return button
end

local bigHeadButton = makeButton("BIG HEAD: OFF", 55)
local espButton = makeButton("NAME + DISTANCE ESP: OFF", 102)
local refreshButton = makeButton("REFRESH PLAYER LIST", 149)
local hideButton = makeButton("HIDE PANEL", 196)

local openButton = Instance.new("TextButton")
openButton.Size = UDim2.fromOffset(90, 34)
openButton.Position = UDim2.new(0, 12, 0.5, 0)
openButton.BackgroundColor3 = Color3.fromRGB(165, 25, 50)
openButton.TextColor3 = Color3.new(1, 1, 1)
openButton.Text = "PRINZZ"
openButton.Font = Enum.Font.GothamBold
openButton.TextSize = 13
openButton.Visible = false
openButton.Parent = gui
Instance.new("UICorner", openButton).CornerRadius = UDim.new(0, 8)

local status = Instance.new("TextLabel")
status.Size = UDim2.new(1, -24, 0, 20)
status.Position = UDim2.fromOffset(12, 239)
status.BackgroundTransparency = 1
status.Text = "Ready | Own-game Studio version"
status.TextColor3 = Color3.fromRGB(190, 165, 175)
status.Font = Enum.Font.Gotham
status.TextSize = 10
status.Parent = panel

local function removeESP(player)
    local object = espObjects[player]
    if object then
        object:Destroy()
        espObjects[player] = nil
    end
end

local function addESP(player)
    if player == localPlayer then return end
    removeESP(player)

    local character = player.Character
    local head = character and character:FindFirstChild("Head")
    if not head then return end

    local billboard = Instance.new("BillboardGui")
    billboard.Name = "PrinzzNameDistance"
    billboard.Adornee = head
    billboard.Size = UDim2.fromOffset(190, 34)
    billboard.StudsOffset = Vector3.new(0, 2.7, 0)
    billboard.AlwaysOnTop = true
    billboard.MaxDistance = 1500
    billboard.Parent = gui

    local label = Instance.new("TextLabel")
    label.Size = UDim2.fromScale(1, 1)
    label.BackgroundTransparency = 1
    label.TextColor3 = Color3.fromRGB(255, 90, 115)
    label.TextStrokeTransparency = 0.2
    label.Font = Enum.Font.GothamBold
    label.TextSize = 12
    label.Text = player.DisplayName .. " | -- studs"
    label.Parent = billboard

    espObjects[player] = billboard
end

local function refreshESP()
    for player in pairs(espObjects) do
        removeESP(player)
    end
    if espEnabled then
        for _, player in ipairs(Players:GetPlayers()) do
            addESP(player)
        end
    end
end

bigHeadButton.MouseButton1Click:Connect(function()
    bigHeadEnabled = not bigHeadEnabled
    bigHeadButton.Text = "BIG HEAD: " .. (bigHeadEnabled and "ON" or "OFF")
    remote:FireServer("SetBigHead", bigHeadEnabled)
    status.Text = "Big Head request sent to server"
end)

espButton.MouseButton1Click:Connect(function()
    espEnabled = not espEnabled
    espButton.Text = "NAME + DISTANCE ESP: " .. (espEnabled and "ON" or "OFF")
    refreshESP()
end)

refreshButton.MouseButton1Click:Connect(function()
    refreshESP()
    status.Text = "Player list refreshed: " .. tostring(#Players:GetPlayers())
end)

hideButton.MouseButton1Click:Connect(function()
    panel.Visible = false
    openButton.Visible = true
end)

openButton.MouseButton1Click:Connect(function()
    panel.Visible = true
    openButton.Visible = false
end)

RunService.RenderStepped:Connect(function()
    if not espEnabled then return end
    local myCharacter = localPlayer.Character
    local myRoot = myCharacter and myCharacter:FindFirstChild("HumanoidRootPart")
    if not myRoot then return end

    for player, billboard in pairs(espObjects) do
        local character = player.Character
        local root = character and character:FindFirstChild("HumanoidRootPart")
        local label = billboard:FindFirstChildOfClass("TextLabel")
        if root and label then
            local distance = (myRoot.Position - root.Position).Magnitude
            label.Text = player.DisplayName .. " | " .. math.floor(distance) .. " studs"
        end
    end
end)

Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function()
        task.wait(1)
        if espEnabled then addESP(player) end
    end)
end)

Players.PlayerRemoving:Connect(removeESP)

for _, player in ipairs(Players:GetPlayers()) do
    player.CharacterAdded:Connect(function()
        task.wait(1)
        if espEnabled then addESP(player) end
    end)
end

print("[PRINZZ] Client panel loaded.")
